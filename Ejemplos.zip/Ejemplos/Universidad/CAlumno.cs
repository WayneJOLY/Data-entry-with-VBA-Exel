﻿namespace Universidad
{
    public class CAlumno
    {
        //Atributos (->Variables miembro).
        //Variables de instancia.
        private ulong leg;
        private string nom;
        private string ape;
        //Variable de clase.
        private static float CUOTA;
        //Comportamientos (->Métodos miembro).
        //Métodos de instancia.
        //Métodos monstructores.
        //Constructor por defecto (sin argumentos o parámetros).
        public CAlumno()
        {
            this.leg = 99999UL;
            this.nom = "N";
            this.ape = "N";
        }
        //Constructores parametrizados (con argumentos o parámetros).
        public CAlumno(ulong legajo)
        {
            this.leg = legajo;
        }
        public CAlumno(string nombre, string apellido)
        {
            this.nom=nombre;
            this.ape = apellido;
        }
        public CAlumno(ulong legajo, string nombre, string apellido)
        {
            this.leg=legajo;    
            this.nom=nombre;
            this.ape=apellido;
        }
        //Setters.
        public void SetLegajo(ulong legajo)
        { this.leg = legajo; }
        public void SetNombre(string nombre)
        { this.nom = nombre; }
        public void SetApellido(string apellido)
        { this.ape = apellido; }
        
        //Getters.
        public ulong GetLegajo()
        { return this.leg; }
        public string GetNombre()
        { return this.nom; }
        public string GetApellido()
        { return this.ape; }    
        //Métodos funcionales.
        public string DarDatos()
        {
            string datos = "Datos del alumno/a: >>> Legajo: " + this.leg.ToString();
            datos += " - " + this.ape + ", " + this.nom;
            datos += " - Cuota General: $ " + CAlumno.CUOTA.ToString() +".";
            return datos;
        }
        //Métodos de clase.
        public static void SetCUOTA(float cuota)
        { CAlumno.CUOTA = cuota; }
        public static float GetCUOTA()
        { return CAlumno.CUOTA; }

    }
}
