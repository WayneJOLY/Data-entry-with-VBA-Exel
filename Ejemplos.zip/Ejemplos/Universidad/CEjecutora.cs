﻿using System;

namespace Universidad
{
    public class CEjecutora
    {
        public static void Main()
        {
            CAlumno.SetCUOTA(48000.27F);
            Console.WriteLine(">> CUOTA General: $" + CAlumno.GetCUOTA().ToString());



            //Finalización.
            Console.Write("Pulse Enter");
            Console.ReadLine();
        }
    }
}
