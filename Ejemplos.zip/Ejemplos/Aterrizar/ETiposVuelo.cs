﻿namespace Aterrizar
{
    enum ETiposVuelo
    {
        Cabotaje,
        Internacional,
    }
}
